Quake-The-Spinning-Corridor
A comptetive Quake stage made for 2-4 players with excessive ability to alter the layout of the map.

Here's the [wiki](https://github.com/LittleFiery1/Quake-The-Spinning-Corridor/wiki)!
